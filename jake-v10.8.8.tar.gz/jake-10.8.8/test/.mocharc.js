
module.exports = {
  ui: 'tdd',
  exclude: [
    'jakefile.js',
    'jakefile.publish.js',
    'jakefile.rule.js',
    'helpers.js'
  ]
}

